const express = require('express');
const mariadb = require('./dbcon.js');
const app = express()
const port = 19830

app.all('/', function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "X-Requested-With");
    next()
});

/*mariadb.pool.getConnection(function(err){
    if (err) throw err;
    console.log('connected');
});
mariadb.pool.query('DROP TABLE IF EXISTS retailers', function(err){
    if(err){
        next(err);
        return;
    }
    mariadb.pool.query("CREATE TABLE retailers (id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(255) NOT NULL, url VARCHAR(50) NOT NULL)", function(err){
        if(err){
            next(err);
            return;
        }
        
        var retailers = [
            ['Amazon', 'Amazon.com'],
            ['Wal-Mart', 'walmart.com']
        ];
        stmt = "INSERT INTO retailers (name, url) VALUES ?;"
        mariadb.pool.query(stmt, [retailers], function(err){
            if (err) throw err;
            mariadb.pool.query('SELECT * FROM retailers', function(err, rows, fields){
                console.log(JSON.stringify(rows));
            });
        });
    });
});*/

app.get('/', (req, res) => {
    let resp = {}
    stmt = 'SELECT * FROM dummy WHERE name=?';
    console.log(req.query.product);
    mariadb.pool.query(stmt, [req.query.product], function(err, rows, fields){
        resp.itemSearched = rows[0].name;
        resp.imageUrl = rows[0].img_url;
        resp.msrp = rows[0].msrp;
        resp.results = [];

        for (let i=0; i < rows.length; i++){
            let newResult = {};
            newResult.retailer = rows[i].retailer;
            newResult.price = rows[i].price;
            newResult.inStock = rows[i].inStock;
            newResult.url = rows[i].url;

            resp.results.push(newResult);
        }

        res.send(resp);
    });
});

app.listen(port, () => console.log(`Example app listening at http://localhost:${port}`))