var mariadb = require('mariadb/callback');
var pool = mariadb.createPool({
  connectionLimit : 10,
  host            : 'price-aggregator-backend.coxajyvhvlmg.us-east-1.rds.amazonaws.com',
  user            : 'dummy_reader',
  password        : 'imadummy',
  database        : 'common_cents'
});

module.exports.pool = pool;